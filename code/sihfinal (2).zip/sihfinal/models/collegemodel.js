var db=require('./conn')
var spawn = require("child_process").spawn;
       

function  fatchevent(cid,cb) {
       console.log(cid)
       db.collection("create_event").find({"c_id":cid}).toArray(function(err,result){
              if(err)
              {
                     console.log(err)
              }
              else{
                     cb(result)
              }
       })
       
}


function fatchalumnilist(data,cb){
       db.collection("Studentdb").find({"c_id":1}).toArray(function(err,result){
              console.log("data is"+data.cid)
              if(err)
              {
                     console.log(err)
              }
              else{
                     cb(result)
              }
       })
}

function updatedata(dat,cb){
       console.log("jcbw")
       var city;
       const pythonProcess = spawn('python',["./python_file/Untitled.ipynb", dat]);
       pythonProcess.stdout.on('data', (data) => {
              d=data.toString
              var i=0;
              for(j=0;j<dat.length;j++)
              {
              while(d[i]!="\n")
              {
                     i++
              }i++
              while(d[i]!="\n")
              {
                     city[j]=city[j]+""+d[i]
                     i++
              }i++
              while(d[i]!="\n")
              {
                     i++
              }i++
       }
       });
       db.collection("Studentdb").update({'s_id':1},{$set:{'current_city':city[0]}}).toArray(function(err,result){
              if(!err){
                     cb(result)
              }
              else{
                     console.log(err)
              }
       })

}

module.exports={fatchevent:fatchevent,fatchalumnilist:fatchalumnilist,updatedata:updatedata}





