var db=require('./conn')

var s_id=1
function register(tbl_name,data,cb){
       var cid
       
              db.collection("collegedb").find({'name':data.cnm}).toArray(function(err,cd){
                     if(err)
                     {
                            console.log(err)
                     }
                     else{
                            cid=cd[0].c_id
                     }
              })
       s_id=s_id+1;
      db.collection("Studentdb").insertOne({'s_id':s_id,'name':data.nm,'passing year':data.pyear,'branch':data.branch,'c_id':cid,'current_city':"",'current_organization':"tata",'gender':data.gender,'hometown_city':'','profile_img':"",'social_media_profile':"",'email':data.email,'mobile':data.mbn,'password':data.pass,'v_status':0},function(err,result){
             if(err){
                    console.log(err)
             }
             else{
                    cb(result)
             }
      }) 
}

function loginCollege(data,cb){
       console.log(data.email+"")
       db.collection("collegedb").find({'email':data.email,'password':data.password}).toArray(function(err,result){
              if(err){
                     console.log(err)
              }
              else{
                     cb(result)
              }
       })
}
function loginStudent(data,cb){
       db.collection("Studentdb").find({'email':data.email,'password':data.password}).toArray(function(err,result){
              if(err){
                     console.log(err)
              }
              else{
                     cb(result)
              }
       })
}



module.exports={register:register,loginCollege:loginCollege,loginStudent:loginStudent}





