var db=require('./conn')

function editprofile(sid,cb)
{
    db.collection("Studentdb").find({"s_id":sid}).toArray(function(err,result){
        if(err)
        {
            console.log(err)
        }
        else{
            cb(result)
        }
    })
}

module.exports={editprofile:editprofile}





