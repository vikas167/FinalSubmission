var mongoose=require('mongoose')

var url="mongodb://localhost:27017/SIH2020"

mongoose.connect(url,function(err,result){
	
	console.log('connection done..11.')
})

var con=mongoose.connection


module.exports=con 

console.log('connection done...')

