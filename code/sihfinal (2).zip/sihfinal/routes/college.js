var express = require('express');
var collegemodel=require('../models/collegemodel')
var url = require('url');

var router = express.Router();

/* GET users listing. */
var Collegeid;
var Collegename;

router.use('/',function(req,res,next){
  Collegeid=req.session.cid
  Collegename=req.session.cnm
  console.log('before rendering')
  if(Collegeid==null)
  {
   console.log('Invalid user please login first, IP tracking')
   res.render('login',{'result':'first fill details'});
  
  }	
  next()
});



router.get('/',function(req,res,next){
  console.log('in collge login')
  collegemodel.fatchevent(Collegeid,function(result){
      console.log(result[0].title  +" : venue")
    res.render('collegeevent',{'data': result,'collegeid':Collegeid});
  })
})

router.all('/updatelist',function(req,res,next){
  
    var d=url.parse(req.url,true).query
    collegemodel.fatchalumnilist(d,function(result){
      console.log("fatching alumni list"+result.length)
      res.render('alumnilist',{'data':result,'collegeid':Collegeid})
    })
})

router.all('/updatedata',function(req,res,next){
  var pu=url.parse(req.url,true).query
  var profileurl=['https://www.linkedin.com/in/himanshu-somani/','https://www.linkedin.com/in/shrikanth-naik-a18491116/','https://www.linkedin.com/in/rajeev-kumar-676590b5/']
  /*for(i=0;i<pu.length-1;i++)
  {
    a="profile"+i
    profileurl[i]=pu.a
  }*/
  //console.log(profileurl)
  collegemodel.updatedata(profileurl,function(result){
    res.render('/updatelist',{'data':result,'collegid':Collegeid})
  })

  /*var arr
  //for(i=0;i<pu.length;i++)
  {
  //  arr[i]=pu[i].social_media_profile
  }
  console.log("hsadfuad" + pu[i].social_media_profile)
  console.log(arr)
    var spawn = require("child_process").spawn; 
    var pythonProcess= spawn('python',["./pythonfile/scrap.ipnyb",arr] ); 
    pythonProcess.stdout.on('data', (data) => {


  });
  res.render('/',{})*/
})



module.exports = router;
