var express = require('express');
var url = require('url');
var studentmodel=require('../models/studentmodel')

var router = express.Router();
var Studentid
/* GET users listing. */
router.use('/',function(req,res,next){
  Studentid=req.session.sid
  //Collegename=req.session.cnm
  console.log('before rendering')
  if(Studentid==null)
  {
   console.log('Invalid user please login first, IP tracking')
   res.render('login',{'result':'first fill details'});
  }	
  next()
});



router.get('/',function(req,res,next){
  console.log('in Alumni login')
  studentmodel.editprofile(Studentid,function(result){
    res.render('editprofile',{'data': result});
  })
})

module.exports = router;
