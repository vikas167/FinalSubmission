var usermodel=require('../models/usersmodel');
var express = require('express');
var url=require('url');
var path=require('path');
var router = express.Router();

var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {
    res.render('index',{})
});

router.all('/register',function(req,res,next){
  if(req.method=="POST"){
    usermodel.register('Studentdb',req.body,function(result){
      if(result){
        res.render('login',{'result':"Register Successfully,Account will be verified by College \n You will get notified by mail"})

      }
      else{
        res.render('login',{'result':"Registeration failed , Please try again"})

      }
    })
  }
});

router.all('/login',function(req,res,next){
  if(req.method=="POST")
  {
    if(req.body.name=="alumni"){
      usermodel.loginStudent(req.body,function(result){
        if(result.length >0){
          req.session.sid=result[0].s_id
          res.redirect('student')
        }
        else{
          res.render('login',{'result':"Can't login"})
        }
      })
    }
    else{
      usermodel.loginCollege(req.body,function(result) {
        if(result.length >0){
          console.log("cnm")
          console.log(result[0].name);
          req.session.cnm=result[0].name;
          req.session.cid=result[0].c_id;
          res.redirect('college')
        }
        else{
          console.log("hello")
          res.render('login',{'result':"Can't login"})
        }
      })
    } /*
    else {
      usermodel.director('director',req.body,function(result) {
        if(result.length >0){
          req.session.dnm=result[0].name
          req.session.did=result[0].c_id
          res.redirect('director')
        }
        else{
          res.render('login',{'result':"Can't login"})
        }
      })
    }*/
  }
  else{
    res.render('login',{'result':''})
  }
})
module.exports = router;
